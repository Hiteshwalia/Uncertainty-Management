NODE_TYPES = ['Person', 'Character', 'Building', 'Country', 'Battle', 'City', 'Island']
RELATION_TYPES = ['Friend', 'Known', 'Kill', 'HasChild', 'Maried', 'Victory', 'Defeat','IsBorn','Belongs']