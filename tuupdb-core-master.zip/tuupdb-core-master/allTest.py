import unittest
from TestUAssertNode import TestInsertDBAssertNode
from TestU2 import TestInsertDB
from TestUAssertRelations import TestInsertDBAssertRelations
from TestUAssertMutex import TestAssertMutexMutex

if __name__ == '__main__':
    unittest.main()
