<template>
  <el-row type="flex">
    <div id="main">
      <div id="searchbar">
        <el-form inline size="small">
          <el-form-item label="Search by">
            <el-select :value="searchForm.searchby" v-model="searchForm.searchby">
              <el-option v-for="(value, index) in searchTypes"
                         :key="index" :value="value">{{value}}
              </el-option>
            </el-select>
          </el-form-item>

          <template v-if="searchForm.searchby === 'Type'">
            <el-form-item label="Entity Type">
              <el-select :value="searchForm.entityType" v-model="searchForm.entityType">
                <el-option v-for="(value, index) in constants.NodeTypes"
                           :key="index" :value="value">{{value}}
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="Relation Type">
              <el-select :value="searchForm.relationType" v-model="searchForm.relationType">
                <el-option v-for="(value, index) in constants.RelationTypes"
                           :key="index" :value="value">{{value}}
                </el-option>
              </el-select>
            </el-form-item>
          </template>
          <template v-else-if="searchForm.searchby === 'Property'">
            <el-form-item label="Key">
              <el-input v-model="searchForm.key"></el-input>
            </el-form-item>
            <el-form-item label="Value">
              <el-input v-model="searchForm.value"></el-input>
            </el-form-item>
          </template>
          <template v-else-if="searchForm.searchby === 'Date'">
            <el-form-item label="Begin">
              <el-date-picker
                v-model="searchForm.begin"
                type="date">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="End">
              <el-date-picker
                v-model="searchForm.end"
                type="date">
              </el-date-picker>
            </el-form-item>
          </template>


          <el-form-item label="Limit">
            <el-input-number v-model="searchForm.limit"></el-input-number>
          </el-form-item>
          <el-button type="primary" icon="el-icon-search" round @click="submitSearch">Search</el-button>
        </el-form>
      </div>
      <div id="graph"></div>
    </div>
    <div id="sidebar">
      <el-tabs v-model="tabActive" type="card">

        <!--  AddNode   -->
        <el-tab-pane label="AddNode" name="AddNode">
          <el-form label-width="10vw" size="mini">
            <el-collapse v-model="accordionActive" accordion>
              <el-collapse-item title="Node information" name="1">
                <el-form-item label="Entity Type">
                  <el-select :value="entityForm.entityType" v-model="entityForm.entityType">
                    <el-option v-for="(value, index) in constants.NodeTypes"
                               :key="index" :value="value">{{value}}
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="Entity ID">
                  <el-input-number v-model="entityForm.entityID"></el-input-number>
                </el-form-item>
                <el-form-item label-width="2em">
                  <el-switch
                    v-model="uncertaintyPeriod"
                    active-text="Uncertain Period"
                    inactive-text="Certain Period">
                  </el-switch>
                </el-form-item>
                <el-form-item :label="uncertaintyPeriod ? 'Begin Begin' : 'Begin'">
                  <el-date-picker
                    v-model="entityForm.knowledgeBeginBegin"
                    type="date"
                    @change="(v) => {!uncertaintyPeriod && (entityForm.knowledgeBeginEnd = v)}">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="Begin End" v-if="uncertaintyPeriod">
                  <el-date-picker
                    v-model="entityForm.knowledgeBeginEnd"
                    type="date">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="End Begin" v-if="uncertaintyPeriod">
                  <el-date-picker
                    v-model="entityForm.knowledgeEndBegin"
                    type="date">
                  </el-date-picker>
                </el-form-item>
                <el-form-item :label="uncertaintyPeriod ? 'End End' : 'End'">
                  <el-date-picker
                    v-model="entityForm.knowledgeEndEnd"
                    type="date"
                    @change="(v) => {!uncertaintyPeriod && (entityForm.knowledgeEndBegin = v)}">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="Knowledge probability">
                  <el-slider
                    id="probability"
                    :min="0" :max="1" :step="0.1"
                    v-model="entityForm.probability"
                    show-input>
                  </el-slider>
                </el-form-item>
              </el-collapse-item>


              <el-collapse-item title="Node properties" name="2">
                <div style="display: flex; padding: 0.1em;" v-for="(value, index) in entityForm.properties"
                     :key="index">
                  <el-input v-model="value.key" placeholder="Key" class="el-col-10" size="mini"></el-input>
                  <el-input v-model="value.value" placeholder="Value" class="el-col-10" size="mini"></el-input>
                  <el-button type="danger" icon="el-icon-delete"
                             circle size="mini"
                             @click="() => {entityForm.properties.splice(index, 1)}">
                  </el-button>
                </div>
                <div style="display: flex; justify-content: center; padding-top: 0.5em;">
                  <el-button
                    type="primary"
                    icon="el-icon-plus"
                    round
                    style="margin: auto"
                    @click="() => {entityForm.properties.push({key: '', value: ''})}">
                    Add property
                  </el-button>
                </div>
              </el-collapse-item>
            </el-collapse>

            <el-form-item label="Add with mutex exclusion">
              <el-switch v-model="entityForm.conflictAccept">
              </el-switch>
            </el-form-item>

            <div style="display: flex; justify-content: center; padding-top: 0.5em;">
              <el-button
                type="primary"
                icon="el-icon-plus"
                round
                style="margin: auto"
                @click="submitNode">
                Add node
              </el-button>
            </div>
          </el-form>
        </el-tab-pane>


        <el-tab-pane label="AddRelation" name="AddRelation">
          <el-form label-width="10vw" size="mini">
            <el-collapse v-model="accordionActive" accordion>
              <el-collapse-item title="Relation information" name="1">
                <el-form-item label="Relation Type">
                  <el-select :value="relationForm.relationType" v-model="relationForm.relationType">
                    <el-option v-for="(value, index) in constants.RelationTypes"
                               :key="index" :value="value">{{value}}
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="Start Node">
                  <el-input-number v-model="relationForm.start" disabled></el-input-number>&nbsp;
                  <el-button size="mini" icon="el-icon-edit" circle type="primary"
                             @click="() => ask('start node')"></el-button>
                </el-form-item>
                <el-form-item label="End Node">
                  <el-input-number v-model="relationForm.end" disabled></el-input-number>&nbsp;
                  <el-button size="mini" icon="el-icon-edit" circle type="primary"
                             @click="() => ask('end node')"></el-button>
                </el-form-item>
                <el-form-item label-width="2em">
                  <el-switch
                    v-model="uncertaintyPeriod"
                    active-text="Uncertain Period"
                    inactive-text="Certain Period">
                  </el-switch>
                </el-form-item>
                <el-form-item :label="uncertaintyPeriod ? 'Begin Begin' : 'Begin'">
                  <el-date-picker
                    v-model="relationForm.knowledgeBeginBegin"
                    type="date"
                    @change="(v) => {!uncertaintyPeriod && (relationForm.knowledgeBeginEnd = v)}">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="Begin End" v-if="uncertaintyPeriod">
                  <el-date-picker
                    v-model="relationForm.knowledgeBeginEnd"
                    type="date">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="End Begin" v-if="uncertaintyPeriod">
                  <el-date-picker
                    v-model="relationForm.knowledgeEndBegin"
                    type="date">
                  </el-date-picker>
                </el-form-item>
                <el-form-item :label="uncertaintyPeriod ? 'End End' : 'End'">
                  <el-date-picker
                    v-model="relationForm.knowledgeEndEnd"
                    type="date"
                    @change="(v) => {!uncertaintyPeriod && (relationForm.knowledgeEndBegin = v)}">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="Knowledge probability">
                  <el-slider
                    id="probability"
                    :min="0" :max="1" :step="0.1"
                    v-model="relationForm.probability"
                    show-input>
                  </el-slider>
                </el-form-item>
              </el-collapse-item>


              <el-collapse-item title="Relation properties" name="2">
                <div style="display: flex; padding: 0.1em;" v-for="(value, index) in relationForm.properties"
                     :key="index">
                  <el-input v-model="value.key" placeholder="Key" class="el-col-10" size="mini"></el-input>
                  <el-input v-model="value.value" placeholder="Value" class="el-col-10" size="mini"></el-input>
                  <el-button type="danger" icon="el-icon-delete"
                             circle size="mini"
                             @click="() => {relationForm.properties.splice(index, 1)}">
                  </el-button>
                </div>
                <div style="display: flex; justify-content: center; padding-top: 0.5em;">
                  <el-button
                    type="primary"
                    icon="el-icon-plus"
                    round
                    style="margin: auto"
                    @click="() => {relationForm.properties.push({key: '', value: ''})}">
                    Add property
                  </el-button>
                </div>
              </el-collapse-item>
            </el-collapse>

            <div style="display: flex; justify-content: center; padding-top: 0.5em;">
              <el-button
                type="primary"
                icon="el-icon-plus"
                round
                style="margin: auto"
                @click="submitRelation">
                Add relation
              </el-button>
            </div>
          </el-form>
        </el-tab-pane>


        <el-tab-pane label="AddMutex" name="AddMutex">
          <el-form size="mini">
            <el-form-item label="Node or relation one">
              <el-input-number v-model="mutex.id1" disabled></el-input-number>&nbsp;
              <el-button size="mini" icon="el-icon-edit" circle type="primary"
                         @click="() => ask('mutex element one')"></el-button>
            </el-form-item>
            <el-form-item label="Node or relation two">
              <el-input-number v-model="mutex.id2" disabled></el-input-number>&nbsp;
              <el-button size="mini" icon="el-icon-edit" circle type="primary"
                         @click="() => ask('mutex element two')"></el-button>
            </el-form-item>
            <div style="display: flex; justify-content: center; padding-top: 0.5em;">
              <el-button
                type="primary"
                icon="el-icon-plus"
                round
                style="margin: auto"
                @click="submitMutex">
                Add mutex
              </el-button>
            </div>
          </el-form>
        </el-tab-pane>
      </el-tabs>
    </div>
  </el-row>
</template>

<script>
  import Neo4jd3 from '../neo4jd3'
  import Vue from 'vue'
  import RESTRequest from '../RESTRequest'
  import ElSwitch from "element-ui/packages/switch/src/component";

  export default {
    components: {ElSwitch},
    data() {
      return {
        searchTypes: ['Date', 'Type', 'Property'],
        searchForm: {
          searchby: 'Date',
          begin: null,
          end: null,
          entityType: null,
          relationType: null,
          key: null,
          value: null,
          limit: 100
        },
        constants: {
          NodeTypes: [],
          RelationTypes: []
        },
        entityForm: {
          entityType: null,
          entityID: null,
          knowledgeBeginBegin: null,
          knowledgeBeginEnd: null,
          knowledgeEndBegin: null,
          knowledgeEndEnd: null,
          probability: 1,
          properties: [{key: '', value: ''}],
          conflictAccept: false
        },
        relationForm: {
          relationType: null,
          start: null,
          end: null,
          knowledgeBeginBegin: null,
          knowledgeBeginEnd: null,
          knowledgeEndBegin: null,
          knowledgeEndEnd: null,
          probability: 1,
          properties: [{key: '', value: ''}]
        },
        mutex: {
          id1: null,
          id2: null
        },
        handle: null,
        uncertaintyPeriod: false,
        accordionActive: '1',
        tabActive: 'AddNode',
        neo4jd3: null
      }
    },
    mounted() {
      RESTRequest(this, 'getAllType')
        .then((json) => {
          this.constants = json
        })

      let _this = this
      this.neo4jd3 = new Neo4jd3('#graph', {
        icons: {
          'Person': 'user',
          'Building': 'bank',
          'Battle': 'flash',
          'City': 'map-marker',
          'Island': 'globe',
          'Country': 'globe'
        },
        minCollision: 60,
        onNodeClick(node) {
          if (_this.handle === 'start node') {
            _this.relationForm.start = node.id
            _this.handle = null
            _this.$notify.success('Node selected')
          } else if (_this.handle === 'end node') {
            _this.relationForm.end = node.id
            _this.handle = null
            _this.$notify.success('Node selected')
          } else if (_this.handle === 'mutex element one') {
            _this.mutex.id1 = node.id
            _this.handle = null
            _this.$notify.success('Element selected')
          } else if (_this.handle === 'mutex element two') {
            _this.mutex.id2 = node.id
            _this.handle = null
            _this.$notify.success('Element selected')
          }
        },
        onRelationshipClick(relation) {
          if (_this.handle === 'mutex element one') {
            _this.mutex.id1 = relation.id
            _this.handle = null
            _this.$notify.success('Element selected')
          } else if (_this.handle === 'mutex element two') {
            _this.mutex.id2 = relation.id
            _this.handle = null
            _this.$notify.success('Element selected')
          }
        },
        onNodeDoubleClick(node) {
          RESTRequest(_this, 'neighbours', node.id)
            .then((json) => {
              _this.neo4jd3.updateWithD3Data(json)
            })
        },
        infoPanel: false,
        onHover(e) {
          popup.$data.element = e
        }
      })

      // this.neo4jd3.updateWithD3Data({
      //   "nodes": [{
      //     "id": 46,
      //     "labels": ["Person"],
      //     "properties": {
      //       "name": "Napoleon 1er",
      //       "Function": "French Emperor",
      //       "knowledgeBeginBegin": "1815-03-20",
      //       "knowledgeBeginEnd": "1815-03-20",
      //       "knowledgeEndBegin": "1815-06-22",
      //       "knowledgeEndEnd": "1815-06-22",
      //       "transactionBegin": "2019-01-28",
      //       "transactionEnd": null,
      //       "probability": 1.0
      //     }
      //   }, {
      //     "id": 29,
      //     "labels": ["Battle"],
      //     "properties": {
      //       "cavaliers français": "12600",
      //       "Canons des alliers": "156",
      //       "name": "Waterloo",
      //       "cavaliers des alliers": "12000",
      //       "fantassins français:": "74000",
      //       "fantassins des alliers:": "68000",
      //       "Canons français": "266",
      //       "knowledgeBeginBegin": "1815-06-18",
      //       "knowledgeBeginEnd": "1815-06-18",
      //       "knowledgeEndBegin": "1815-06-19",
      //       "knowledgeEndEnd": "1815-06-19",
      //       "transactionBegin": "2019-01-28",
      //       "transactionEnd": null,
      //       "probability": 1.0
      //     }
      //   }, {
      //     "id": 26,
      //     "labels": ["Person"],
      //     "properties": {
      //       "name": "Josephine Beauharnais",
      //       "knowledgeBeginBegin": "1796-03-09",
      //       "knowledgeBeginEnd": "1796-03-09",
      //       "knowledgeEndBegin": "1809-12-16",
      //       "knowledgeEndEnd": "1809-12-16",
      //       "transactionBegin": "2019-01-28",
      //       "transactionEnd": null,
      //       "probability": 1.0
      //     }
      //   }, {
      //     "id": 27,
      //     "labels": ["Person"],
      //     "properties": {
      //       "name": "Marie-Louise d’Autriche",
      //       "function": "Archduchesse",
      //       "knowledgeBeginBegin": "1810-04-02",
      //       "knowledgeBeginEnd": "1810-04-02",
      //       "knowledgeEndBegin": "1847-12-17",
      //       "knowledgeEndEnd": "1847-12-17",
      //       "transactionBegin": "2019-01-28",
      //       "transactionEnd": null,
      //       "probability": 1.0
      //     }
      //   }],
      //   "relationships": [{
      //     "id": -31,
      //     "type": "Defeat",
      //     "startNode": 46,
      //     "endNode": 29,
      //     "properties": {
      //       "Résultat": "Napoleon Exilé",
      //       "knowledgeBeginBegin": "1815-06-18",
      //       "knowledgeBeginEnd": "1815-06-18",
      //       "knowledgeEndBegin": "1815-06-19",
      //       "knowledgeEndEnd": "1815-06-19",
      //       "transactionBegin": "2019-01-28",
      //       "transactionEnd": null,
      //       "probability": 1.0
      //     }
      //   }, {
      //     "id": -33,
      //     "type": "Maried",
      //     "startNode": 46,
      //     "endNode": 26,
      //     "properties": {
      //       "Raison du divorce": "Stérilité de Joséphine",
      //       "knowledgeBeginBegin": "1796-03-09",
      //       "knowledgeBeginEnd": "1796-03-09",
      //       "knowledgeEndBegin": "1809-12-16",
      //       "knowledgeEndEnd": "1809-12-16",
      //       "transactionBegin": "2019-01-28",
      //       "transactionEnd": null,
      //       "probability": 1.0
      //     }
      //   }, {
      //     "id": -35,
      //     "type": "Maried",
      //     "startNode": 46,
      //     "endNode": 27,
      //     "properties": {
      //       "Raison du divorce": "Mort de Louise-Marie",
      //       "knowledgeBeginBegin": "1810-04-02",
      //       "knowledgeBeginEnd": "1810-04-02",
      //       "knowledgeEndBegin": "1847-12-17",
      //       "knowledgeEndEnd": "1847-12-17",
      //       "transactionBegin": "2019-01-28",
      //       "transactionEnd": null,
      //       "probability": 1.0
      //     }
      //   }], mutex: [[26,27], [-33, -35], [-31, 26]]
      // })

      let popup = new Vue({
        data() {
          return {
            element: {}
          }
        },
        template: `
            <div>
              <p><strong>type: </strong>{{element.labels && element.labels[0] || element.type}}</p>
              <p v-for="(value, key) in element.properties || {}" :key="key">
                <strong>{{key}}: </strong>{{value}}
              </p>
            </div>`,
        parent: this
      }).$mount('#popupContent')
    },
    methods: {
      ask(handle) {
        this.handle = handle
        this.$notify.info('Please select ' + handle)
      },
      submitNode() {
        let data = Object.assign({}, this.entityForm)
        data.properties = {}

        Object.keys(data).forEach((k) => {
          if (k.startsWith('knowledge')) {
            let m = data[k]
            if (m) {
              data[k] = m.getUTCFullYear() + '-' +
                ('0' + (m.getUTCMonth() + 1)).slice(-2) + '-' +
                ('0' + m.getUTCDate()).slice(-2)
            }
          }
        })

        this.entityForm.properties.forEach((obj) => {
          data.properties[obj.key] = obj.value
        })
        RESTRequest(this, 'addNode', data)
          .then((res) => {
            this.$notify.success('Node added')
            this.neo4jd3.updateWithD3Data(res)
          })
      },
      submitRelation() {
        let data = Object.assign({}, this.relationForm)
        data.properties = {}

        Object.keys(data).forEach((k) => {
          if (k.startsWith('knowledge')) {
            let m = data[k]
            if (m) {
              data[k] = m.getUTCFullYear() + '-' +
                ('0' + (m.getUTCMonth() + 1)).slice(-2) + '-' +
                ('0' + m.getUTCDate()).slice(-2)
            }
          }
        })

        this.relationForm.properties.forEach((obj) => {
          data.properties[obj.key] = obj.value
        })
        RESTRequest(this, 'addRelation', data)
          .then((res) => {
            this.$notify.success('Relation added')
            this.neo4jd3.updateWithD3Data(res)
          })
      },
      submitMutex() {
        RESTRequest(this, 'addMutex', this.mutex)
          .then((res) => {
            this.$notify.success('Mutex added')
            this.neo4jd3.updateWithD3Data(res)
          })
      },
      submitSearch() {
        let data = Object.assign({}, this.searchForm)

        if (data.begin) {
          data.begin = data.begin.getUTCFullYear() + '-' +
            ('0' + (data.begin.getUTCMonth() + 1)).slice(-2) + '-' +
            ('0' + data.begin.getUTCDate()).slice(-2)
        }
        if (data.end) {
          data.end = data.end.getUTCFullYear() + '-' +
            ('0' + (data.end.getUTCMonth() + 1)).slice(-2) + '-' +
            ('0' + data.end.getUTCDate()).slice(-2)
        }

        RESTRequest(this, 'search', data)
          .then((res) => {
            if(
              (!res.nodes || Array.isArray(res.nodes) && res.nodes.length === 0) &&
              (!res.relationships || Array.isArray(res.nodes) && res.nodes.length === 0) &&
              (!res.nodes || Array.isArray(res.nodes) && res.nodes.length === 0)
            ) {
              this.$notify.warning('Nothing was found!')
            } else {
              this.neo4jd3.updateWithD3Data(res)
            }
          })
      }
    }
  }
</script>

<style>
  #main {
    display: flex;
    flex-direction: column;
  }
  #searchbar {
    height: calc(10vh - 2px);
    border-bottom: #333333 solid 2px;
    display: flex;
    align-items: center;
  }
  #searchbar .el-form-item {
    margin-bottom: 0;
  }
  /*#searchbar .el-select, #searchbar .el-date-editor {*/
    /*!*max-width: 9vw;*!*/
    /*width: auto;*/
  /*}*/
  #searchbar .el-input {
    /*width: auto;*/
    max-width: 7vw;
  }
  #searchbar .el-input-number .el-input {
    max-width: none;
  }
  #graph {
    width: 70vw;
    height: 90vh;
    overflow: hidden;
  }

  #sidebar {
    width: calc(30vw - 2px);
    height: 100vh;
    border-left: #333333 solid 2px;
    overflow: auto;
  }

  div.tooltip {
    position: absolute;
    font: 14px sans-serif;
    padding: 0.5em;
    min-width: 10vw;
    background: rgba(0, 0, 0, 0.8);
    color: #fff;
    border-radius: 8px;
    pointer-events: none;
    left: 0;
    top: 0;
  }

  div.tooltip p {
    padding: 0.2em;
  }

  #probability {
    display: flex;
    flex-direction: column-reverse;
  }

  #probability .el-slider__input {
    float: none;
  }

  #probability .el-slider__runway {
    margin-right: 0;
    width: 90%;
  }
</style>
