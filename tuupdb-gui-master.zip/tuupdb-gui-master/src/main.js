import './styles.scss'
import './assets/css/neo4jd3.scss'
import 'font-awesome/scss/font-awesome.scss'

import Vue from 'vue'
import App from './App'
import i18n from './i18n'
import VueResource from 'vue-resource'

import ElementUI from 'element-ui'

Vue.use(ElementUI, {
  i18n: (key, value) => i18n.t(key, value)
})
Vue.use(VueResource)

Vue.config.productionTip = false

new Vue({
  i18n,
  render: h => h(App)
}).$mount('#app')
