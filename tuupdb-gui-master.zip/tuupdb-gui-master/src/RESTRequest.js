const REST_URL = 'http://192.168.43.18:5000/'
const ROUTE_MAPPING = {
  neighbours: {
    method: 'get',
    url: (id) => `getNeighbours/${id}`
  },
  getAllType: {
    method: 'get',
    url: () => 'getAllType'
  },
  addNode: {
    method: 'post',
    url: () => 'createNode'
  },
  addRelation: {
    method: 'post',
    url: () => 'createRelation'
  },
  addMutex: {
    method: 'post',
    url: () => 'createMutex'
  },
  search: {
    method: 'post',
    url: () => 'researchInformation'
  }
}

export default function (vue, request, params = {}) {
  return new Promise((resolve, reject) => {
    let route = ROUTE_MAPPING[request]
    if (route) {
      vue.$http[route.method](REST_URL + route.url(params), params)
        .then((response) => {
          resolve(response.json())
        })
        .catch((err) => {
          vue.$notify.error({
            title: err.message || (err.statusText && (err.status + ': ' + err.statusText)) || vue.$i18n.t('CONNECTION_FAILED'),
            message: err.body || err.bodyText
          })
          reject(err)
        })
    } else {
      reject(new Error(vue.$i18n.t('INVALID_ROUTE')))
    }
  })
}
